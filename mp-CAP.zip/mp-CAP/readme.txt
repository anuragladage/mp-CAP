tap_milp.jl: Source file for milp formulation
tap_ColumnGen.jl: Source file for column generation framework.


1. Do not change the structure of the directory. All paths are relative to the tap_ColumnGen.jl file path. Set IDE or present working directory to src file directory.
2. View docstrings for function definition and help.
3. Update file paths in get_data function if required
4. Version parameter can be ignored. Was used during experimentation.
