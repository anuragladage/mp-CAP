#This file contains code for the Tank Allocation Problem using Julia 1.6 and solver
#Legs 0 to |K| in C++ are 1 to |K|+1 here.

using JuMP
using CPLEX
using CPUTime
using Gurobi

local_path = true
version=1

solver=Gurobi.Optimizer
##


##Data setting
struct Data
    totalship::Int64; totalports::Int64; totallegs::Int64; totalcompartments::Int64;
    K::Vector{Int64}; ## AE:in general for speed/efficiency it's better to tell the compiler what the types are
    ship_route;
    zeta_O::Vector{Int64};
    zeta_X::Vector{Vector{Int64}};
    H::UnitRange{Int64};
    H_N::Vector{Vector{Int64}};
    V_H::Vector{Int64}; zeta_I::Vector{Vector{Int64}};
    C_C::Int64;  ## However it doesn't really matter here
    kappa::Vector{Float64}; iota::Vector{Float64}; alpha::Int64; beta::Int64;
    rho_zeta::Vector{Float64}; W::Vector{Float64}; P_L::Vector{String}; P_D::Vector{String};
    zeta::Vector{Int64}; # set of all cargos
    zeta_per_leg::Vector{Vector{Int64}}; # cargos for each leg
    K_j::Dict{Int64,Vector{Int64}} # legs for each cargo
end

function get_data(instance_iter,ship_no)
    main_data_folder, sspdptwtac_sol_path = "Dummy"
    if local_path == true
        main_data_folder = "./Data/Instance_set_"
        sspdptwtac_sol_path = string("./Data/s-PDP-TWTAC_sol/ss_htsrsp_rev_sol_set_$instance_iter","_ver_1_s$ship_no.txt")
    else
        main_data_folder = "/home/alad5/p2016050003/alad5/Server_Runs_Cplex_12_7_1/Data/Instance_set_"
        sspdptwtac_sol_path = string("/home/alad5/p2016050003/alad5/Server_Runs_Cplex_12_7_1/Solutions/Default_Runs/Ver_1/Instance_set_$instance_iter/Sol/ss_htsrsp_rev_sol_set_$instance_iter","_ver_1_s$ship_no.txt")
    end

    ##Setting paths of all data files
    # main_data_folder = "Data/Instance_set_"
    problem_data_path = string(main_data_folder,"$instance_iter/problem_data.dat")
    ship_data_path = string(main_data_folder,"$instance_iter/S$ship_no","_data.dat",)
    onboard_cargo_path = string(main_data_folder, "$instance_iter/S$ship_no","_onboard_cargoes.dat")
    unassigned_cargo_path = string(main_data_folder, "$instance_iter/S$ship_no","_unassigned_cargoes.dat")
    # sspdptwtac_sol_path = string("Data/Instance_set_$instance_iter/
    ##Reading data from file
    problem_data = readlines(problem_data_path)
    ship_data = readlines(ship_data_path)
    onboard_cargo = readlines(onboard_cargo_path)
    unassigned_cargo = readlines(unassigned_cargo_path)
    sspdptwtac_sol = readlines(sspdptwtac_sol_path)

    totalship = 1
    totalports = parse(Int64, problem_data[1])
    totallegs = parse(Int64, ship_data[5])+1 #0 to |K| in data files is 1 to |K|+1 here as indexing starts from 1.
    totalcompartments = parse(Int64, ship_data[6])
    K = Vector{Int64}(1:totallegs);
    ship_route_line = findfirst( x -> occursin("-->", x), sspdptwtac_sol)
    ship_route = split(sspdptwtac_sol[ship_route_line],r" --> |is ",keepempty=false)[2:end]
    #Make sure there are onboard cargoes
    onboard_cargoes_line = 18 + totalcompartments + 3 #18 comes from the fixed data before the start of compartment data, which varies with tankers.
    if length(ship_data) == onboard_cargoes_line
        zeta_O = parse.(Int64,split(ship_data[onboard_cargoes_line]," "))
    else
        zeta_O = Vector{Int64}()
    end
    zeta_X =  Vector{Vector{Int64}}()
    H = 1:totalcompartments;
    H_N =  Vector{Int64}[] # list of vectors
    V_H =  Vector{Int64}()
    for iter in 19:(19+totalcompartments-1)
        words = split(ship_data[iter])
        push!(V_H,parse(Int64,words[3]))
        if length(words) >= 5
            push!(H_N,parse.(Int64,split(words[5],",")))
        else
            push!(H_N,Vector{Int64}())
        end
        if length(words) >= 6
            push!(zeta_X,parse.(Int64,split(words[6],",")))
        else
            push!(zeta_X,Vector{Int64}())
        end
    end

    zeta_I = Vector{Vector{Int64}}()
    for iter in 1:length(unassigned_cargo)
        words = split(unassigned_cargo[iter])
        if length(words) == 13
            push!(zeta_I,parse.(Int64,split(words[13],",")))
        else
            push!(zeta_I,Vector{Int64}())
        end
    end
    if length(zeta_O) > 0
        for iter in 1:length(onboard_cargo)
            words = split(onboard_cargo[iter])
            if length(words) == 11
                push!(zeta_I,parse.(Int64,split(words[11],",")))
            else
                push!(zeta_I,Vector())
            end
        end
    end

    C_C = parse(Int64, ship_data[18]);
    kappa = parse.(Float64,split(ship_data[14]," "))
    iota = parse.(Float64,split(ship_data[15]," "))
    alpha = parse(Int64,ship_data[12])
    beta = parse(Int64,ship_data[13])
    rho_zeta = Vector{Float64}()
    W = Vector{Float64}()
    P_L = Vector{String}()
    P_D = Vector{String}()
    if !isempty(unassigned_cargo)
        for iter in unassigned_cargo
            words = split(iter," ")
            push!(rho_zeta,parse(Float64,words[4]))
            push!(W,parse(Float64,words[2]))
            push!(P_L,words[10])
            push!(P_D,words[11])
        end
    end
    if !isempty(onboard_cargo)
        for iter in onboard_cargo
            words = split(iter," ")
            push!(rho_zeta,parse(Float64,words[4]))
            push!(W,parse(Float64,words[2]))
            push!(P_L,words[8])
            push!(P_D,words[9])
        end
    end

    ##Populating set of all cargoes for TAP
    cargoes_served_line = findfirst( x -> occursin("Cargoes served", x), sspdptwtac_sol)
    cargo_start_index = findfirst( x -> occursin("are", x), split(sspdptwtac_sol[cargoes_served_line]," "))+1
    zeta = parse.(Int64, split(sspdptwtac_sol[cargoes_served_line])[7:end])

    ##Populating zeta per leg
    zeta_per_leg_temp = Vector{Set{Int64}}(undef,totallegs)
    zeta_per_leg = [Vector{Int64}() for iter=1:totallegs]
    for iter in 1:length(zeta_per_leg_temp)
        zeta_per_leg_temp[iter] = Set{Int64}()
    end
    w_var_lines = findall( x -> occursin("w_", x), sspdptwtac_sol)
    for line_index in w_var_lines
        words = split(sspdptwtac_sol[line_index],('_'))
        push!(zeta_per_leg_temp[parse(Int64,words[3])+1],parse(Int64,words[4]))
    end
    #Converting set to array
    for iter in 1:length(zeta_per_leg)
        zeta_per_leg[iter] = sort(collect(zeta_per_leg_temp[iter]))
    end

    ##Populating K_j
    #For onboard cargoes
    K_j = Dict( j=>Vector{Int64}() for j=zeta)
    for cargo_iter in zeta_O
        discharge_leg = findfirst( x -> occursin(P_D[cargo_iter], x), ship_route)
        K_j[cargo_iter] = collect(1:(discharge_leg-1))
    end
    #For unassigned cargoes
    for cargo_iter in setdiff(zeta,zeta_O)
        pickup_leg = findfirst( x -> occursin(P_L[cargo_iter], x), ship_route)
        discharge_leg = findfirst( x -> occursin(P_D[cargo_iter], x), ship_route)
        K_j[cargo_iter] = collect(pickup_leg:(discharge_leg-1))
    end
    return Data(totalship, totalports, totallegs, totalcompartments,
                K, ship_route, zeta_O, zeta_X, H, H_N, V_H, zeta_I, C_C,
                kappa, iota, alpha, beta, rho_zeta, W, P_L, P_D, zeta, zeta_per_leg, K_j)
end

"""
LPBound: Solves the lp relaxation of the MILP formulation for the mp-CAP. Returns objective function value\n
Parameters:\n
instance_iter: Instance set number.\n
ship_no: Ship number within an instance set.\n
d1 (Data object): Data object generated by get_data function.\n
doInt (Bool): True solve the milp formulation, false solve its LP relaxation.\n
writeSolFile: If true, generates a solution text file
silent (Bool) Turns of the solver log.\n
timeLimit (seconds): Specifies the time limit in seconds. Use solver specific parameters to toggle between CPU and wall clock time.
"""
function LPBound(instance_iter, ship_no, d1::Data; doInt=false, writeSolFile=false, silent=false, timeLimit=1800)
    CPUtic()
    start_time = time()
    # d1 = Data()
    # set_data(d1,instance_iter,ship_no)
    tap = Model(solver)
    if silent
        set_silent(tap)
    end
    ##Defining variables
    @variable(tap, c[k in d1.K,j in d1.zeta,h in d1.H],lower_bound = 0, upper_bound = 1,binary=doInt)
    @variable(tap, w[k in d1.K,j in d1.zeta,h in d1.H],lower_bound = 0)
    @variable(tap, 0 <= b[k in d1.K,j in d1.zeta,h in d1.H] <= 1)

    total_variables = length(c) + length(w)+ length(b)
    #Pre-processing
    for k in d1.K
        for j in d1.zeta
            for h in d1.H
                #Cargo-compartment incompatibility
                if length(findall( x -> x == j, d1.zeta_X[h])) > 0
                    set_upper_bound(w[k,j,h],0)
                #Last leg all cargoes delivered
                elseif k == length(d1.K)
                    set_upper_bound(w[k,j,h],0)
                #Cargoes allowed only when loaded on the tanker
                elseif length(findall( x -> x == k, d1.K_j[j])) == 0
                    set_upper_bound(w[k,j,h],0)
                else
                    set_upper_bound(w[k,j,h],d1.V_H[h]*d1.rho_zeta[j])
                end
            end
        end
    end
    ##Defining constraints
    total_constraints = 0
    #Cargoes onboard the tanker should be assigned to atleast one compartment
    @constraint(tap,cargo_assign_atleast_one_comp[j in d1.zeta, k in d1.K_j[j]],sum(c[k,j,h] for h in d1.H) >= 1)
    total_constraints += length(cargo_assign_atleast_one_comp)
    #A compartment has to be empty or loaded with atmost one cargo.
    @constraint(tap,one_cargo_per_compartment[k in d1.K,h in d1.H],sum(c[k,j,h] for j in d1.zeta_per_leg[k]) <= 1)
    total_constraints += length(one_cargo_per_compartment)
    #Changeover constraint - part 2
    @constraint(tap, changeover_constr2[j in d1.zeta,k in d1.K_j[j][2:end], h in d1.H],c[(k-1),j,h] - c[k,j,h] >= -b[k,j,h])
    total_constraints += length(changeover_constr2)

    #Changeover constraint - part 1
    # for j in d1.zeta
    #     if length(d1.K_j[j]) > 0
    #         @constraint(tap, [h in d1.H], b[d1.K_j[j][1],j,h] == c[d1.K_j[j][1],j,h])
    #         total_constraints += length(H)
    #     end
    # end
    @constraint(tap, changeover_constr1[j in d1.zeta,h in d1.H; length(d1.K_j[j]) > 0], b[d1.K_j[j][1],j,h] == c[d1.K_j[j][1],j,h])
    #Cargo cargo incompatibility constraint
    @constraint(tap, cargo_cargo_compatibility[k in d1.K,j in d1.zeta_per_leg[k],h in d1.H, h_dash in d1.H_N[h]], c[k,j,h] + sum(c[k,j_dash,h_dash] for j_dash in intersect(d1.zeta_I[j],d1.zeta_per_leg[k])) <= 1)
    total_constraints += length(cargo_cargo_compatibility)
    #Compartment capacity constraint
    @constraint(tap, compartment_capacity[j in d1.zeta, k in d1.K_j[j], h in d1.H], w[k,j,h] <= d1.V_H[h]*d1.rho_zeta[j]*c[k,j,h])
    total_constraints += length(compartment_capacity)
    #Total cargo weight constraint
    @constraint(tap, total_cargo_weight[j in d1.zeta, k in d1.K_j[j]], sum(w[k,j,h] for h in d1.H) == d1.W[j])
    total_constraints += length(total_cargo_weight)
    #Trim constraint - 1
    @constraint(tap, trim_constraint1[k in d1.K], sum(w[k,j,h]*d1.iota[h] for h in d1.H, j in d1.zeta_per_leg[k]) <= d1.alpha)
    total_constraints += length(trim_constraint1)
    #Trim constraint - 2
    @constraint(tap, trim_constraint2[k in d1.K], sum(w[k,j,h]*d1.iota[h] for h in d1.H, j in d1.zeta_per_leg[k]) >= -d1.alpha)
    total_constraints += length(trim_constraint2)
    #Heel constraint - 1
    @constraint(tap, heel_constraint1[k in d1.K], sum(w[k,j,h]*d1.kappa[h] for h in d1.H, j in d1.zeta_per_leg[k]) <= d1.beta)
    total_constraints += length(heel_constraint1)
    #Heel constraint - 2
    @constraint(tap, heel_constraint2[k in d1.K], sum(w[k,j,h]*d1.kappa[h] for h in d1.H, j in d1.zeta_per_leg[k]) >= -d1.beta)
    total_constraints += length(heel_constraint2)


    ##Defining objective function
    @objective(tap, Min, d1.C_C*sum(b[k,j,h] for k in d1.K, j in d1.zeta, h in d1.H))

    ##Setting Cplex parameters
    if solver_name(tap) == "CPLEX"
        set_optimizer_attribute(tap, "CPXPARAM_ClockType", 1)
        set_optimizer_attribute(tap, "CPXPARAM_Threads", 4)
    elseif solver_name(tap) == "Gurobi"
        set_optimizer_attribute(tap, "Threads", 4)
    end
    set_time_limit_sec(tap,timeLimit)
    optimize!(tap)
    cpu_time_elapsed = CPUtoc()
    wall_time_elapsed = time() - start_time
    # println("Completed LP solve in $(wall_time_elapsed) sec ($(cpu_time_elapsed) CPU). Objective = ",objective_value(tap))
    if writeSolFile
        if local_path
            solpath = "tap_sol_set_$(instance_iter)_default_v$(version)_s$(ship_no).txt"
        else
            solpath = "Solutions/TAP/Default_Runs/Ver_$(version)/Instance_set_$(instance_iter)/Sol/tap_sol_set_$(instance_iter)_default_v$(version)_s$(ship_no).txt"
        end
        open(solpath,"w") do file
            write(file, "Instance_set_$(instance_iter)_solution TAP_v$(version)_default formulation. Solved using Julia 1.6.1 and $(solver_name(tap))\n")
            write(file, "Customized parameter settings are as follows:\n")
            if solver_name(tap) == "CPLEX"
                write(file, "CPU TimeLimit = $(get_optimizer_attribute(tap,"CPXPARAM_TimeLimit"))\n")
                write(file, "Threads = $(get_optimizer_attribute(tap,"CPXPARAM_Threads"))\n")
                write(file, "ClockType = $(get_optimizer_attribute(tap,"CPXPARAM_ClockType"))\n")
            elseif solver_name(tap) == "Gurobi"
                write(file, "TimeLimit (sec) = $(get_optimizer_attribute(tap, "TimeLimit"))\n")
                write(file, "Threads = $(get_optimizer_attribute(tap, "Threads"))\n")
            end

            write(file, "solution status = $(termination_status(tap))\n")
            if doInt == true
                write(file, "Final Relative Gap = $(relative_gap(tap))\n")
            end
            write(file, "Total number of variables: $(total_variables)\n")
            write(file, "Total number of constraints: $(total_constraints)\n")
            write(file, "Nodes explored: $(node_count(tap))\n\n")
            write(file, """
            Ship no: $ship_no
            Number of legs (Without leg 0): $(length(d1.K)-1)
            Optimal objective function value = $(objective_value(tap))
            Total CPU time (sec) = $(round(cpu_time_elapsed,digits = 2))
            Total Wall Clock time (sec) = $(round(wall_time_elapsed, digits = 2))

            Solution:
            """)

            for k in d1.K
                for j in d1.zeta
                    for h in d1.H
                        if value(c[k,j,h]) > 0.00001
                            write(file, "c_$(ship_no)_$(k)_$(j)_$(h) = $(value(c[k,j,h]))\n")
                        end
                    end
                end
            end
            for k in d1.K
                for j in d1.zeta
                    for h in d1.H
                        if value(w[k,j,h]) > 0.00001
                            write(file, "w_$(ship_no)_$(k)_$(j)_$(h) = $(round(value(w[k,j,h]), digits = 6))\n")
                        end
                    end
                end
            end
            for k in d1.K
                for j in d1.zeta
                    for h in d1.H
                        if value(b[k,j,h]) > 0.00001
                            write(file, "b_$(ship_no)_$(k)_$(j)_$(h) = $(round(value(b[k,j,h]),digits = 6))\n")
                        end
                    end
                end
            end
        end
    else
        return objective_value(tap)
    end
end

LPBound(22,3, get_data(22, 3), silent=true)
instance_iter = 1
ship_no = 3
if !local_path
    instance_iter = parse(Int64,ARGS[1])
    ship_no = parse(Int64,ARGS[2])
end
LPBound(instance_iter,ship_no, get_data(instance_iter, ship_no), doInt=true, writeSolFile=true)

#To solve LP
# LPBound(instance_iter,ship_no, false,true,true)
