This folder contains data for 15 test instances presented in the book chapter for the book titled 'Optimization Techniques: Theory and Practice'. The complete data is originally used to solve a bigger scheduling problem. A subset of this data is used for the multi-period cargo assignment problem (mp-CAP).

Each Instance_iter_ folder contains problem_data, ship_data, ship_onboard_cargo_data, ship_unassigned_cargo_data, and readme.txt. Contents of these files are organised as follows:

readme.txt structure
total_ships
total_cargoes
network_number
total_planning_time
cargo_complexity
totallegs
ship_util_level
number_of_discharge_ports
loading_Rate
unloading_Rate
administrative_Time
alpha
beta

A single instance consists of 4 files. 
1] problem_data.dat: This file contains port data and distances.
2] S{SHIP_NO}_data.dat: This is the ship data file. It contains all the ship related data.
3] S{SHIP_NO}_onboard_cargoes.dat: Contains all the data related to cargoes onboard the ship at time zero.
4] S{SHIP_NO}_unassigned_cargoes.dat: Contains all the data related to unassigned cargoes that can be picked up by the ship within the planning horizon.

The problem_data.dat file is same for all the instances within a single instance set.


SHIP DATA FILE STRUCTURE:
ship_number 
ship_name
ship_deadweight
ship_volume
total_legs
total_compartments
arrival_time
ship_speed
draft_constant (Draft constant can be interchanged with the total_ship_capacity as it is a upper bound on the total cargo_weight that can be stored on the ships.)
ship_length
empty_weight
alpha
beta
kappa
iota
fuel_cost
charter_cost
changeover_cost
compartment_number compartment_name compartment_volume(m^3) compartment_material neighbours incompatible_cargoes
.
.
.
compartment_number compartment_name compartment_volume(m^3) compartment_material neighbours incompatible_cargoes
immediate_destination
port_cost_vector (Length equal to total number of ports)
onboard_cargoes_vector


PROBLEM DATA FILE STRUCTURE:
totalports
admin_time
port_names
port_distances

ONBOARD CARGO DATA FILE STRUCTURE
cargo_no cargo_weight cargo_volume cargo_density revenue/unit_cargo loading_rate unloading_rate loading_port unloading_port cargo_category incompatible_cargo_list

UNASSIGNED CARGO DATA FILE STRUCTURE
list of unassigned cargoes
cargo_no cargo_weight cargo_volume cargo_density revenue/unit_cargo loading_rate unloading_rate earliest_pickup_time latest_pickup_time loading_port unloading_port cargo_category incompatible_cargo_list
