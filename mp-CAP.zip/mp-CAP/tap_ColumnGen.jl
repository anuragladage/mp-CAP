#--------------------Implementation notes----------------#
# Please view docstrings for function definition and help
# Update file paths as required
# version parameter can be ignored. Was used during experimentation.
# Do not change the structure of the directory. All paths are relative to the tap_ColumnGen.jl file path. Set IDE present working directory to src file directory.
#---------------------------------------------------------#


using JuMP
#using CPLEX
using Gurobi
using CPUTime
using DataStructures
using Printf
using Graphs, SimpleWeightedGraphs
SOLVER=Gurobi.Optimizer
local_path=true
version=21
##Data setting
struct Data
    totalship::Int64; totalports::Int64; totallegs::Int64; totalcompartments::Int64;
    K::Vector{Int64}; ## AE:in general for speed/efficiency it's better to tell the compiler what the types are
    ship_route;
    zeta_O::Vector{Int64};
    zeta_X::Vector{Vector{Int64}};
    H::UnitRange{Int64};
    H_N::Vector{Vector{Int64}};
    V_H::Vector{Int64}; zeta_I::Vector{Vector{Int64}};
    C_C::Int64;  ## However it doesn't really matter here
    kappa::Vector{Float64}; iota::Vector{Float64}; alpha::Int64; beta::Int64;
    rho_zeta::Vector{Float64}; W::Vector{Float64}; P_L::Vector{String}; P_D::Vector{String};
    zeta::Vector{Int64}; # set of all cargos
    zeta_per_leg::Vector{Vector{Int64}}; # cargos for each leg
    K_j::Dict{Int64,Vector{Int64}} # legs for each cargo
end

function get_data(instance_iter,ship_no)
    main_data_folder, sspdptwtac_sol_path = "Dummy"
    if local_path == true
        main_data_folder = "./Data/Instance_set_"
        sspdptwtac_sol_path = string("./Data/s-PDP-TWTAC_sol/ss_htsrsp_rev_sol_set_$instance_iter","_ver_1_s$ship_no.txt")
    else
        main_data_folder = "/home/alad5/p2016050003/alad5/Server_Runs_Cplex_12_7_1/Data/Instance_set_"
        sspdptwtac_sol_path = string("/home/alad5/p2016050003/alad5/Server_Runs_Cplex_12_7_1/Solutions/Default_Runs/Ver_1/Instance_set_$instance_iter/Sol/ss_htsrsp_rev_sol_set_$instance_iter","_ver_1_s$ship_no.txt")
    end

    ##Setting paths of all data files
    # main_data_folder = "Data/Instance_set_"
    problem_data_path = string(main_data_folder,"$instance_iter/problem_data.dat")
    ship_data_path = string(main_data_folder,"$instance_iter/S$ship_no","_data.dat",)
    onboard_cargo_path = string(main_data_folder, "$instance_iter/S$ship_no","_onboard_cargoes.dat")
    unassigned_cargo_path = string(main_data_folder, "$instance_iter/S$ship_no","_unassigned_cargoes.dat")
    # sspdptwtac_sol_path = string("Data/Instance_set_$instance_iter/
    ##Reading data from file
    problem_data = readlines(problem_data_path)
    ship_data = readlines(ship_data_path)
    onboard_cargo = readlines(onboard_cargo_path)
    unassigned_cargo = readlines(unassigned_cargo_path)
    sspdptwtac_sol = readlines(sspdptwtac_sol_path)

    totalship = 1
    totalports = parse(Int64, problem_data[1])
    totallegs = parse(Int64, ship_data[5])+1 #0 to |K| in data files is 1 to |K|+1 here as indexing starts from 1.
    totalcompartments = parse(Int64, ship_data[6])
    K = Vector{Int64}(1:totallegs);
    ship_route_line = findfirst( x -> occursin("-->", x), sspdptwtac_sol)
    ship_route = split(sspdptwtac_sol[ship_route_line],r" --> |is ",keepempty=false)[2:end]
    #Make sure there are onboard cargoes
    onboard_cargoes_line = 18 + totalcompartments + 3 #18 comes from the fixed data before the start of compartment data, which varies with tankers.
    if length(ship_data) == onboard_cargoes_line
        zeta_O = parse.(Int64,split(ship_data[onboard_cargoes_line]," "))
    else
        zeta_O = Vector{Int64}()
    end
    zeta_X =  Vector{Vector{Int64}}()
    H = 1:totalcompartments;
    H_N =  Vector{Int64}[] # list of vectors
    V_H =  Vector{Int64}()
    for iter in 19:(19+totalcompartments-1)
        words = split(ship_data[iter])
        push!(V_H,parse(Int64,words[3]))
        if length(words) >= 5
            push!(H_N,parse.(Int64,split(words[5],",")))
        else
            push!(H_N,Vector{Int64}())
        end
        if length(words) >= 6
            push!(zeta_X,parse.(Int64,split(words[6],",")))
        else
            push!(zeta_X,Vector{Int64}())
        end
    end

    zeta_I = Vector{Vector{Int64}}()
    for iter in 1:length(unassigned_cargo)
        words = split(unassigned_cargo[iter])
        if length(words) == 13
            push!(zeta_I,parse.(Int64,split(words[13],",")))
        else
            push!(zeta_I,Vector{Int64}())
        end
    end
    if length(zeta_O) > 0
        for iter in 1:length(onboard_cargo)
            words = split(onboard_cargo[iter])
            if length(words) == 11
                push!(zeta_I,parse.(Int64,split(words[11],",")))
            else
                push!(zeta_I,Vector())
            end
        end
    end

    C_C = parse(Int64, ship_data[18]);
    kappa = parse.(Float64,split(ship_data[14]," "))
    iota = parse.(Float64,split(ship_data[15]," "))
    alpha = parse(Int64,ship_data[12])
    beta = parse(Int64,ship_data[13])
    rho_zeta = Vector{Float64}()
    W = Vector{Float64}()
    P_L = Vector{String}()
    P_D = Vector{String}()
    if !isempty(unassigned_cargo)
        for iter in unassigned_cargo
            words = split(iter," ")
            push!(rho_zeta,parse(Float64,words[4]))
            push!(W,parse(Float64,words[2]))
            push!(P_L,words[10])
            push!(P_D,words[11])
        end
    end
    if !isempty(onboard_cargo)
        for iter in onboard_cargo
            words = split(iter," ")
            push!(rho_zeta,parse(Float64,words[4]))
            push!(W,parse(Float64,words[2]))
            push!(P_L,words[8])
            push!(P_D,words[9])
        end
    end

    ##Populating set of all cargoes for TAP
    cargoes_served_line = findfirst( x -> occursin("Cargoes served", x), sspdptwtac_sol)
    cargo_start_index = findfirst( x -> occursin("are", x), split(sspdptwtac_sol[cargoes_served_line]," "))+1
    zeta = parse.(Int64, split(sspdptwtac_sol[cargoes_served_line])[7:end])

    ##Populating zeta per leg
    zeta_per_leg_temp = Vector{Set{Int64}}(undef,totallegs)
    zeta_per_leg = [Vector{Int64}() for iter=1:totallegs]
    for iter in 1:length(zeta_per_leg_temp)
        zeta_per_leg_temp[iter] = Set{Int64}()
    end
    w_var_lines = findall( x -> occursin("w_", x), sspdptwtac_sol)
    for line_index in w_var_lines
        words = split(sspdptwtac_sol[line_index],('_'))
        push!(zeta_per_leg_temp[parse(Int64,words[3])+1],parse(Int64,words[4]))
    end
    #Converting set to array
    for iter in 1:length(zeta_per_leg)
        zeta_per_leg[iter] = sort(collect(zeta_per_leg_temp[iter]))
    end

    ##Populating K_j
    #For onboard cargoes
    K_j = Dict( j=>Vector{Int64}() for j=zeta)
    for cargo_iter in zeta_O
        discharge_leg = findfirst( x -> occursin(P_D[cargo_iter], x), ship_route)
        K_j[cargo_iter] = collect(1:(discharge_leg-1))
    end
    #For unassigned cargoes
    for cargo_iter in setdiff(zeta,zeta_O)
        pickup_leg = findfirst( x -> occursin(P_L[cargo_iter], x), ship_route)
        discharge_leg = findfirst( x -> occursin(P_D[cargo_iter], x), ship_route)
        K_j[cargo_iter] = collect(pickup_leg:(discharge_leg-1))
    end
    return Data(totalship, totalports, totallegs, totalcompartments,
                K, ship_route, zeta_O, zeta_X, H, H_N, V_H, zeta_I, C_C,
                kappa, iota, alpha, beta, rho_zeta, W, P_L, P_D, zeta, zeta_per_leg, K_j)
end

# function minCargoCompAllocation(d1::Data,sailLeg)
#     volumeSum = cumsum(sort(d1.V_H,rev=true)) #Cumulative sum of sorted compartment volumes
#     lowerBounds = Dict() #Final return value
#     for cargo in d1.zeta_per_leg[sailLeg]
#         for compIndex in 1:d1.totalcompartments
#             if d1.W[cargo] > volumeSum[compIndex]*d1.rho_zeta[cargo]
#                 continue
#             else
#                 lowerBounds[cargo] = compIndex
#                 break
#             end
#         end
#     end
#     return lowerBounds
# end

"""
LPBound: Solves the lp relaxation of the MILP formulation for the mp-CAP. Returns a list of objective value and dual values.\n
Parameters:\n
Data (Data object): Data object generated by get_data function.\n
doInt (Bool): True solve the milp formulation, false solve its LP relaxation.\n
silent (Bool) Turns of the solver log.\n
solver: Specify the solver. Eg: solver=Gurobi.Optimizer calls the gurobi solver.\n
timeLimit (seconds): Specifies the time limit in seconds. Use solver specific parameters to toggle between CPU and wall clock time.
"""
function LPBound(d1::Data,doInt=false;silent=false,solver=SOLVER,timeLimit=1800)
    ζ = d1.zeta_per_leg # shorthand for frequently used arrays
    tap = Model(solver)
    if silent; set_silent(tap); end
    ##Defining variables
    @variable(tap, c[k in d1.K,j in d1.zeta,h in d1.H],lower_bound = 0, upper_bound = 1,binary=doInt)
    @variable(tap, w[k in d1.K,j in d1.zeta,h in d1.H],lower_bound = 0)
    @variable(tap, 0 <= b[k in d1.K,j in d1.zeta,h in d1.H] <= 1)
    @variable(tap, 0 <= r[k in d1.K[2:end],j in d1.zeta,h in d1.H] <= 1)

    total_variables = length(c) + length(w)+ length(b)+ length(r)
    #Pre-processing
    for k in d1.K
        for j in d1.zeta
            for h in d1.H
                #Cargo-compartment incompatibility
                if length(findall( x -> x == j, d1.zeta_X[h])) > 0
                    set_upper_bound(w[k,j,h],0); set_upper_bound(c[k,j,h],0)
                #Last leg all cargoes delivered
                elseif k == length(d1.K)
                    set_upper_bound(w[k,j,h],0); set_upper_bound(c[k,j,h],0)
                #Cargoes allowed only when loaded on the tanker
                elseif length(findall( x -> x == k, d1.K_j[j])) == 0
                    set_upper_bound(w[k,j,h],0); set_upper_bound(c[k,j,h],0)
                else
                    set_upper_bound(w[k,j,h],d1.V_H[h]*d1.rho_zeta[j])
                end
            end
        end
    end
    ##Defining constraints
    #Cargoes onboard the tanker should be assigned to atleast one compartment
    @constraint(tap,cargo_assign_atleast_one_comp[j in d1.zeta, k in d1.K_j[j]],sum(c[k,j,h] for h in d1.H) >= 1)
    #A compartment has to be empty or loaded with atmost one cargo.
    @constraint(tap,one_cargo_per_compartment[k in d1.K,h in d1.H],sum(c[k,j,h] for j = ζ[k]) <= 1)
    #Changeover constraint - part 2
    @constraint(tap, changeover_constr2[k=d1.K, j=ζ[k], h=d1.H;k != d1.K_j[j][1]],
        c[(k-1),j,h] - c[k,j,h] >= -b[k,j,h])
    @constraint(tap, changeover_constr1[j in d1.zeta,h in d1.H; length(d1.K_j[j]) > 0],
        -c[d1.K_j[j][1],j,h] >= -b[d1.K_j[j][1],j,h])

    #Cargo cargo incompatibility constraint
    @constraint(tap, cargo_cargo_compatibility[k in d1.K, j in ζ[k], h in d1.H, h1 in d1.H_N[h]],
        c[k,j,h] + sum(c[k,j1,h1] for j1 in intersect(d1.zeta_I[j],ζ[k])) <= 1)
    #Compartment capacity constraint
    @constraint(tap, compartment_capacity[j in d1.zeta, k in d1.K_j[j], h in d1.H], w[k,j,h] <= d1.V_H[h]*d1.rho_zeta[j]*c[k,j,h])
    #Total cargo weight constraint
    @constraint(tap, total_cargo_weight[j in d1.zeta, k in d1.K_j[j]], sum(w[k,j,h] for h in d1.H) == d1.W[j])
    #Trim constraint - 1
    @constraint(tap, trim_constraint1[k in d1.K], sum(w[k,j,h]*d1.iota[h] for h=d1.H, j=ζ[k]) <= d1.alpha)
    #Trim constraint - 2
    @constraint(tap, trim_constraint2[k in d1.K], sum(w[k,j,h]*d1.iota[h] for h=d1.H, j=ζ[k]) >= -d1.alpha)
    #Heel constraint - 1
    @constraint(tap, heel_constraint1[k in d1.K], sum(w[k,j,h]*d1.kappa[h] for h=d1.H, j=ζ[k]) <= d1.beta)
    #Heel constraint - 2
    @constraint(tap, heel_constraint2[k in d1.K], sum(w[k,j,h]*d1.kappa[h] for h=d1.H, j=ζ[k]) >= -d1.beta)

    ##Defining objective function
    @objective(tap, Min, d1.C_C*sum(b[k,j,h] for k in d1.K, j in d1.zeta, h in d1.H))

    ##Setting Cplex parameters
    if solver_name(tap) == "CPLEX"
        set_optimizer_attribute(tap, "CPXPARAM_ClockType", 1)
        set_optimizer_attribute(tap, "CPXPARAM_Threads", 4)
    elseif solver_name(tap) == "Gurobi"
        set_optimizer_attribute(tap, "Threads", 4)
    end
    set_time_limit_sec(tap,timeLimit)
    CPUtic()
    optstat = @timed optimize!(tap)
    cpu_time_elapsed = CPUtoc()
    println("Completed LP solve in $(optstat.time) sec ($(cpu_time_elapsed) CPU). Objective = ",objective_value(tap))
    if doInt
        μ = Dict{ Tuple{Int64, Int64, Int64}, Float64}()
        mu_3 = Float64[]
    else
        μ = Dict( (k,j,h) => (k==d1.K_j[j][1] ? abs(dual(changeover_constr1[j,h])) :
                                                abs(dual(changeover_constr2[k,j,h])))
                 for k=d1.K for j=ζ[k] for h in d1.H)
        mu_3 = [ (isempty(ζ[k]) ? 0.0 : sum(dual(cargo_assign_atleast_one_comp[j,k]) for j=ζ[k]))
                for k = d1.K] #Dual variables
    end
    return objective_value(tap), μ,mu_3
end

"""
initialLPSol: Generates a initial cargo-compartment allocation from a given Data object. Returns assignmment variables (c) and cargo-compartment weight allocations (w).\n

Parameters:\n
Data (Data object): Data object generated by get_data function.\n
solver: Specify the solver. Eg: solver=Gurobi.Optimizer calls the gurobi solver.\n
"""
function initialLPSol(d1::Data;solver=SOLVER)
    tap = Model(solver); set_silent(tap)
    ##Defining variables
    @variable(tap, c[j in d1.zeta,k in d1.K_j[j],h in d1.H],lower_bound = 0, upper_bound = 1)
    @variable(tap, w[j in d1.zeta,k in d1.K_j[j],h in d1.H],lower_bound = 0)
    @variable(tap, 0 <= b[j in d1.zeta, k in d1.K_j[j],h in d1.H] <= 1)

    total_variables = length(c) + length(w)+ length(b)
    #Pre-processing
    for j in d1.zeta
        for h in d1.H
            for k in d1.K_j[j]
                #Cargo-compartment incompatibility
                if length(findall( x -> x == j, d1.zeta_X[h])) > 0
                    set_upper_bound(w[j,k,h],0)
                else
                    set_upper_bound(w[j,k,h],d1.V_H[h]*d1.rho_zeta[j])
                end
            end
        end
    end
    ##Defining constraints
    #Cargoes onboard the tanker should be assigned to atleast one compartment
    @constraint(tap,cargo_assign_atleast_one_comp[j in d1.zeta, k in d1.K_j[j]],sum(c[j,k,h] for h in d1.H) >= 1)
    #A compartment has to be empty or loaded with atmost one cargo.
    @constraint(tap,one_cargo_per_compartment[k in d1.K,h in d1.H],sum(c[j,k,h] for j in d1.zeta_per_leg[k]) <= 1)
    #Changeover constraint - part 2
    @constraint(tap, changeover_constr2[j in d1.zeta,k in d1.K_j[j][2:end], h in d1.H;length(d1.K_j[j]) > 0],c[j,(k-1),h] - c[j,k,h] >= -b[j,k,h])
    @constraint(tap, changeover_constr1[j in d1.zeta,h in d1.H; length(d1.K_j[j]) > 0], b[j,d1.K_j[j][1],h] == c[j,d1.K_j[j][1],h])
    #Cargo cargo incompatibility constraint
    @constraint(tap, cargo_cargo_compatibility[k in d1.K,j in d1.zeta_per_leg[k],h in d1.H, h_dash in d1.H_N[h]], c[j,k,h] + sum(c[j_dash,k,h_dash] for j_dash in intersect(d1.zeta_I[j],d1.zeta_per_leg[k])) <= 1)
    #Compartment capacity constraint
    @constraint(tap, compartment_capacity[j in d1.zeta, k in d1.K_j[j], h in d1.H], w[j,k,h] <= d1.V_H[h]*d1.rho_zeta[j]*c[j,k,h])
    #Total cargo weight constraint
    @constraint(tap, total_cargo_weight[j in d1.zeta, k in d1.K_j[j]], sum(w[j,k,h] for h in d1.H) == d1.W[j])
    #Trim constraint - 1
    @constraint(tap, trim_constraint1[k in d1.K], sum(w[j,k,h]*d1.iota[h] for h in d1.H, j in d1.zeta_per_leg[k]) <= d1.alpha)
    #Trim constraint - 2
    @constraint(tap, trim_constraint2[k in d1.K], sum(w[j,k,h]*d1.iota[h] for h in d1.H, j in d1.zeta_per_leg[k]) >= -d1.alpha)
    #Heel constraint - 1
    @constraint(tap, heel_constraint1[k in d1.K], sum(w[j,k,h]*d1.kappa[h] for h in d1.H, j in d1.zeta_per_leg[k]) <= d1.beta)
    #Heel constraint - 2
    @constraint(tap, heel_constraint2[k in d1.K], sum(w[j,k,h]*d1.kappa[h] for h in d1.H, j in d1.zeta_per_leg[k]) >= -d1.beta)

    ##Defining objective function
    @objective(tap, Min, 0)
    if solver_name(tap) == "CPLEX" ##Setting Cplex parameters
        set_optimizer_attribute(tap, "CPXPARAM_ClockType", 1)
        set_optimizer_attribute(tap, "CPXPARAM_Threads", 4)
    elseif solver_name(tap) == "Gurobi"
        set_optimizer_attribute(tap, "Threads", 4)
    end
    set_time_limit_sec(tap,1800)

    CPUtic()
    optstat = @timed optimize!(tap)
    cpu_time_elapsed = CPUtoc()
    println("Completed initLP solve in $(optstat.time) sec ($(cpu_time_elapsed) CPU). Objective = ",
        objective_value(tap))
    c_values = OrderedDict((k,j,h) => value(c[j,k,h]) for j in d1.zeta for k in d1.K_j[j] for h in d1.H)
    w_values = OrderedDict((k,j,h) => value(w[j,k,h]) for j in d1.zeta for k in d1.K_j[j] for h in d1.H)
    # w_values = OrderedDict()
    # for j in d1.zeta
    #     for k in d1.K_j[j]
    #         for
    #     end
    # end
    #     ,,h in d1.H
    # for
    return c_values, w_values
end

"""
generateInitialMilpCols: Generates initial set of columns by reading the mp-CAP MILP solution file. Returns a list of c_values (cargo-compartment assignment variable) and w_values (cargo-compartment weights).\n
Parameters:\n
instance_iter: Instance set number\n
ship_no: Ship number\n
d1: Data object retured by get_data function\n
"""
function generateInitialMilpCols(instance_iter,ship_no,d1)
    c_values = OrderedDict()
    w_values = OrderedDict()
    sspdptwtac_sol_path = "Dummy"
    if local_path == true
        sspdptwtac_sol_path = string("/Users/anuragladage/Documents/Thesis_Codes/Codes/C++/HTSRSP/Server_Runs/Problem_2/Solutions/ss_htsrsp_rev/MonarchV2_Runs/Single_Ship/Default_Runs/Ver_1/Instance_set_$instance_iter/Sol/ss_htsrsp_rev_sol_set_$instance_iter","_ver_1_s$ship_no.txt")
    else
        sspdptwtac_sol_path = string("/home/alad5/p2016050003/alad5/Server_Runs_Cplex_12_7_1/Solutions/Default_Runs/Ver_1/Instance_set_$instance_iter/Sol/ss_htsrsp_rev_sol_set_$instance_iter","_ver_1_s$ship_no.txt")
    end
    sspdptwtac_sol = readlines(sspdptwtac_sol_path)
    c_var_lines = findall( x -> occursin("c_", x), sspdptwtac_sol)
    #Populate c_values
    for line_index in c_var_lines
        words = split(sspdptwtac_sol[line_index],('_',' '))
        if words[4] != "0"
            leg = parse(Int64,words[3])+1
            cargo = parse(Int64,words[4])
            comp = parse(Int64,words[5])
            value_temp = round(parse(Float64,last(words)))
            c_values[(leg,cargo,comp)] = value_temp
        end
    end
    #Populate w_values
    w_var_lines = findall( x -> occursin("w_", x), sspdptwtac_sol)
    for line_index in w_var_lines
        words = split(sspdptwtac_sol[line_index],('_',' '))
        if words[4] != "0"
            leg = parse(Int64,words[3])+1
            cargo = parse(Int64,words[4])
            comp = parse(Int64,words[5])
            value_temp = parse(Float64,last(words))
            w_values[(leg,cargo,comp)] = value_temp
        end
    end
    return c_values, w_values
end

"""
subproblem: Creates subproblem model for the column generation framework. Returns a list of model object, c_values, w_values, total_variables, total_constraints.\n

Parameters:\n
d1: Data object retured by get_data function.\n
k: Sailing leg or sub-problem k to be generated.\n
solver: Specify the solver. Eg: solver=Gurobi.Optimizer calls the gurobi solver.
"""
function subproblem(d1::Data,k;solver=SOLVER)
    SP = Model(solver); set_silent(SP)
    ζ = d1.zeta_per_leg
    @variable(SP, c[j in ζ[k],h in d1.H],Bin)
        # lower_bound = 0, upper_bound = 1)
    @variable(SP, w[j in ζ[k],h in d1.H],lower_bound = 0)
    if length(ζ) == 0; return SP,c,w; end # empty model
    # d_jh = 1-c_jh
    @variable(SP, d[j in ζ[k],h in d1.H],Bin)
    #q = total number of compartments occupied by cargo j. Used to change branching priority
    @variable(SP,q[j in ζ[k]],lower_bound = 1, upper_bound = length(d1.H),integer = true)
    # for j in ζ[k]
    #     MOI.set(SP,Gurobi.VariableAttribute("BranchPriority"),q[j],50)
    # end
    #Pre-processing
    for j in ζ[k], h in d1.H
        #Cargo-compartment incompatibility
        if length(findall( x -> x == j, d1.zeta_X[h])) > 0
            set_upper_bound(w[j,h],0); set_upper_bound(c[j,h],0);
            set_lower_bound(d[j,h],1);
        #Last leg all cargoes delivered
        elseif k == length(d1.K)
            set_upper_bound(w[j,h],0); set_upper_bound(c[j,h],0);
            set_lower_bound(d[j,h],1);
        #Cargoes allowed only when loaded on the tanker
        elseif length(findall( x -> x == k, d1.K_j[j])) == 0
            set_upper_bound(w[j,h],0); set_upper_bound(c[j,h],0);
            set_lower_bound(d[j,h],1);
        else
            set_upper_bound(w[j,h],d1.V_H[h]*d1.rho_zeta[j])
        end
    end
    #Cargoes onboard the tanker should be assigned to atleast one compartment
    # lowerBounds = minCargoCompAllocation(d1, k)
    @constraint(SP,cargo_assign_atleast_one_comp_sp[ j=ζ[k] ],sum(c[j,h] for h in d1.H) >= q[j])
    #A compartment has to be empty or loaded with atmost one cargo.
    @constraint(SP,one_cargo_per_compartment_sp[h in d1.H],sum(c[j,h] for j=ζ[k]) <= 1)
    #Cargo cargo incompatibility constraint
    @constraint(SP, cargo_cargo_compatibility_sp[j in d1.zeta_per_leg[k],h in d1.H, h_dash in d1.H_N[h]],
        c[j,h] + sum(c[j_dash,h_dash] for j_dash in intersect(d1.zeta_I[j],ζ[k])) <= 1)
    #Decision w related constraints.
    #Compartment capacity constraint
    @constraint(SP, compartment_capacity_sp[j=ζ[k], h=d1.H], w[j,h] ≤ d1.V_H[h]*d1.rho_zeta[j]*c[j,h])
    #Total cargo weight constraint
    @constraint(SP, total_cargo_weight_sp[j=ζ[k]], sum(w[j,h] for h in d1.H) == d1.W[j])
    #Trim constraint - 1
    @constraint(SP, trim_constr1_sp, sum(w[j,h]*d1.iota[h] for h=d1.H, j=ζ[k]) <= d1.alpha)
    #Trim constraint - 2
    @constraint(SP, trim_constr2_sp, sum(w[j,h]*d1.iota[h] for h=d1.H, j=ζ[k]) >= -d1.alpha)
    #Heel constraint - 1
    @constraint(SP, heel_constr1_sp, sum(w[j,h]*d1.kappa[h] for h=d1.H, j=ζ[k]) <= d1.beta)
    #Heel constraint - 2
    @constraint(SP, heel_constr2_sp, sum(w[j,h]*d1.kappa[h] for h=d1.H, j=ζ[k]) >= -d1.beta)
    #constraints for knapsack constraint
    @constraint(SP, knapsack_def[j=ζ[k], h=d1.H], d[j,h] == 1 - c[j,h])
    @constraint(SP, knapsack_constr[j=ζ[k]], sum(d1.V_H[h]*d1.rho_zeta[j]*d[j,h] for h in d1.H) <= (sum(d1.V_H[h]*d1.rho_zeta[j] for h in d1.H) - d1.W[j]))
    if solver_name(SP) == "CPLEX"
        set_optimizer_attribute(SP, "CPXPARAM_ClockType", 1)
        set_optimizer_attribute(SP, "CPXPARAM_Threads", 4)
    elseif solver_name(SP) == "Gurobi"
        # set_optimizer_attribute(SP, "Threads", 4)
        # set_optimizer_attribute(SP, "MIPFocus", 2)
        # set_optimizer_attribute(SP, "SolutionLimit", 1)
    end
    set_time_limit_sec(SP,1800)
    total_vars_sp = num_variables(SP) #Stores total_vars for individual sub-problems
    total_constrs_sp = sum(num_constraints(SP, F, S) for (F, S) in list_of_constraint_types(SP)) #Stores total number of constraints per sub-problem.
    return SP, c, w, total_vars_sp, total_constrs_sp # return objective_value(SP),c_valuesm, w_values, total_vars, total_constraints.
end

"""
lagrangian: Calculates the lagrangian bound for a given subproblem. Returns the lagrangian bound.\n

Parameters:\n
SPvals: Objective function of the sub-problem.\n
mu_1, mu_3: Dual values obtained from solving the master problem.
"""
function lagrangian(SPvals, mu_1, mu_3)
    return sum(sp for sp=SPvals)
end

"""
get_dw_sp_obj: Computes a single coefficient for Δ (the sub-problem objective function) using repair heuristic coef and duals. Returns a single Δ term.\n

Parameters:\n
d1: Data object retured by get_data function.\n
μ: Data structure containing dual values
k,j,h: Index terms getting a single dual values from μ.
sp_coef: Repair heuristic coefficient.
"""
#
function  get_dw_sp_obj(d1::Data,μ,k,j,h,sp_coef)
    Δ = μ[k,j,h] + sp_coef
    if k != last(d1.K_j[j]); Δ -= μ[k+1,j,h]; end
    return Δ
end

"""
get_dw_sp_obj: Computes a single coefficient for Δ (the sub-problem objective function) only duals. Returns a single Δ term. Here Δ is the reduced cost.\n

Parameters:\n
d1: Data object retured by get_data function.\n
μ: Data structure containing dual values
k,j,h: Index terms getting a single dual values from μ.
"""
# compute a single coefficient only using duals
function  get_dw_sp_obj(d1::Data,μ,k,j,h)
    Δ = μ[k,j,h]
    if k != last(d1.K_j[j]); Δ -= μ[k+1,j,h]; end
    return Δ
end

"""
writeSoltoFile: Writes solution to a text file.

Parameters:\n
d1: Data object retured by get_data function.\n
instance_iter: Instance set number\n
ship_no: Ship number\n
final_master_obj: Final master problem objective before termination.\n
final_lagrangian_obj: Best lagrangian bound found before termination.\n
final_sol: Best integer solution found before termination\n
cpu_time_elapsed: Total CPU elapsed time. (Ignore in case of parallel runs) \n
solver: Solver\n
wall_time: Total wall clock time.
"""
function writeSoltoFile(d1::Data,instance_iter, ship_no, final_master_obj, final_lagrangian_obj, final_sol, cpu_time_elapsed=0;solver=SOLVER, wall_time=0)
    solName = solver_name(Model(solver))
    solpath = "Dummy"
    if local_path
        solpath = "./tap_sol_set_$(instance_iter)_dw_v$(version)_s$(ship_no).txt"
    else
        solpath = "Solutions/TAP/DW_Runs/Ver_$(version)/Instance_set_$(instance_iter)/Sol/tap_sol_set_$(instance_iter)_DW_v$(version)_s$(ship_no).txt"
    end
    open(solpath,"w") do file
        write(file, "Instance_set_$(instance_iter)_solution TAP_v$(version) Dantzig Wolfe formulation.\n")
        write(file, "Solved using Julia $(VERSION), colum_gen and $solName")
        write(file, """
        Instance_iter: $instance_iter
        Ship no: $ship_no
        Number of legs (Without leg 0): $(length(d1.K)-1)
        Best integer objective: $(final_sol["obj"])
        Best master objective value = $(round(final_master_obj, digits = 4))
        Best lagrangian objective value = $(round(final_lagrangian_obj, digits = 4))\n""")
        if cpu_time_elapsed == -1
            write(file,"Total Wall time (sec) = $(round(wall_time,digits = 2))\nDW CG solution:\n")
        else
            write(file,"Total CPU time (sec) = $(round(cpu_time_elapsed,digits = 2))\nDW CG solution:\n")
        end


        for k in keys(final_sol["c"]), (j,h) in keys(final_sol["c"][k])
            write(file, "c_$(ship_no)_$(k)_$(j)_$(h) = $(final_sol["c"][k][j,h])\n")
        end
        for k in keys(final_sol["w"]), (j,h) in keys(final_sol["w"][k])
            write(file, "w_$(ship_no)_$(k)_$(j)_$(h) = $(round(final_sol["w"][k][j,h], digits=6))\n")
        end
        for (k,j,h) in keys(final_sol["b"])
            if final_sol["b"][k,j,h] > 0
                write(file, "b_$(ship_no)_$(k)_$(j)_$(h) = $(round(final_sol["b"][k,j,h], digits = 6))\n")
            end
        end
    end
end

"""
writeRepairHeurSolToFile: Writes solution to a text file.

Parameters:\n
instance_iter: Instance set number\n
ship_no: Ship number\n
iter: Iteration number
sailing_leg_vector: Vector of sailing leg numbers
temp_corner_points: Vector of ordered dicts of corner points generated till present iteration. \n
final_w_values: Vector of ordered dicts of weight allocations corresponding to corner points. \n
repairHeur_best_sol: Best integer solution generated by the repair heuristic. \nn
repairHeur_wall_time: Total repair heuristic wall clock time. \n
solver=SOLVER
"""
function writeRepairHeurSolToFile(instance_iter, ship_no, iter, sailing_leg_vector, temp_corner_points, final_w_values, repairHeur_best_sol, repairHeur_wall_time;solver=SOLVER)
    solName = solver_name(Model(solver))
    solpath = "Dummy"
    if local_path
        solpath = "./tap_repairHeur_sol_set_$(instance_iter)_dw_v$(version)_s$(ship_no).txt"
    else
        solpath = "Solutions/TAP/DW_Runs/Ver_$(version)/Instance_set_$(instance_iter)/Sol/tap_repairHeur_sol_set_$(instance_iter)_dw_v$(version)_s$(ship_no).txt"
    end
    open(solpath,"w") do file
        write(file,"Best repair heuristic solution found at iteration: $iter\n")
        write(file,
        "Repair heuristic Obj: $repairHeur_best_sol\n")
        write(file,
        "Repair heuristic Wall time (sec): $(round(repairHeur_wall_time,digits=2))\n")
        for k in sailing_leg_vector
            if length(temp_corner_points[k]) > 0
                for (j,h) in keys(temp_corner_points[k])
                    if temp_corner_points[k][j,h] > 0
                        write(file, "c_$(ship_no)_$(k)_$(j)_$(h) = $(temp_corner_points[k][j,h])\n")
                    end
                end
            end
        end
        for k in sailing_leg_vector
            # print("Test print: $(final_w_values[k])\n")
            if length(final_w_values[k]) > 0
                for (j,h) in keys(final_w_values[k])
                    if final_w_values[k][j,h] > 0
                        write(file, "w_$(ship_no)_$(k)_$(j)_$(h) = $(final_w_values[k][j,h])\n")
                    end
                end
            end
        end
    end
    file = open(solpath,"a");
    for k in sailing_leg_vector
        if k != last(sailing_leg_vector)
            writeEdgeValueFromWeight_2(k+1, final_w_values[k], final_w_values[k+1], file)
        end
    end
    close(file)
end

"""
generateEdgeValue: Given 2 corner points or columns calculates the total number of changeovers (Σb) value from cp1 to cp2. A column is here the cargo-compartment assignment for a given leg. Can only handle non-zero values. Work with corner points where zero values are filtered before hand. Returns edge value
"""
function generateEdgeValue(cp1,cp2)
    edge_value = 0
    for key_cp2 in keys(cp2)
        if !(key_cp2 in keys(cp1))
            edge_value += 1
        end
    end
    return edge_value
end

"""
generateEdgeValue: Given 2 corner points or columns calculates the total number of changeovers (Σb) value from cp1 to cp2. A column is here the cargo-compartment assignment for a given leg. Can only handle zero values as well.
"""
function generateEdgeValue_2(cp1,cp2)
    edge_value = 0
    for key_cp2 in keys(cp2)
        if cp2[key_cp2] > 0
            if !(key_cp2 in keys(cp1))
                edge_value += 1
            elseif cp1[key_cp2] == 0
                edge_value += 1
            end
        end
    end
    return edge_value
end

"""
Calculates total changeovers from weight vectors instead of allocation vectors.
"""
function generateEdgeValueOnWeight_2(weight_cp1,weight_cp2)
    edge_value = 0
    for key_cp2 in keys(weight_cp2)
        if weight_cp2[key_cp2] > 0
            if !(key_cp2 in keys(weight_cp1))
                edge_value += 1
            elseif weight_cp1[key_cp2] == 0
                edge_value += 1
            end
        end
    end
    return edge_value
end

"""
Calculates and writes changeover variables (b) from weight vectors instead of allocation vectors.
"""
#Similar to generateEdgeValue_2. Just writes to file.
function writeEdgeValue_2(leg_cp2, cp1,cp2, file)
    for key_cp2 in keys(cp2)
        if cp2[key_cp2] > 0
            if !(key_cp2 in keys(cp1))
                write(file, "b_$(leg_cp2)_$(key_cp2) = 1\n")
            elseif cp1[key_cp2] == 0
                write(file, "b_$(leg_cp2)_$(key_cp2) = 1\n")
            end
        end
    end
end

"""
Similar to generateEdgeValueOnWeight_2. Just writes to file.
"""
function writeEdgeValueFromWeight_2(leg_cp2, weight_cp1,weight_cp2, file)
    for key_cp2 in keys(weight_cp2)
        if weight_cp2[key_cp2] > 0
            if !(key_cp2 in keys(weight_cp1))
                write(file, "b_$(leg_cp2)_$(key_cp2) = 1\n")
            elseif weight_cp1[key_cp2] == 0
                write(file, "b_$(leg_cp2)_$(key_cp2) = 1\n")
            end
        end
    end
end

"""
generate_b_val: Generates the final changeover variable (b) values given a shortest column path.\n

Parameters:\n
final_columns_name: index of corner points.\n
compact_column_list: list of columns returned from shortest_path function. \n
"""
function generate_b_val(final_columns_name, compact_column_list)
    b_values = OrderedDict()
    index = 1
    while index <= length(final_columns_name)
        #cp1_name and cp2_name first index is leg and second is corner_point_number
        cp1_name = final_columns_name[index]
        #At leg 1 b value = number of cargo compartment assignments.
        if index == 1
            for (key,value) in compact_column_list[cp1_name[1]][cp1_name[2]]
                b_values[cp1_name[1],key[1],key[2]] = value
            end
        end
        if (index+1) <= length(final_columns_name)
            cp2_name = final_columns_name[index+1]
            cp1 = compact_column_list[cp1_name[1]][cp1_name[2]]
            cp2 = compact_column_list[cp2_name[1]][cp2_name[2]]
            for key_cp2 in keys(cp2)
                if !(key_cp2 in keys(cp1))
                    b_values[cp2_name[1],key_cp2[1],key_cp2[2]] = cp2[key_cp2]
                end
            end
        end
        index += 1
    end
    return b_values
end

"""
shortest_path: Given a vector corner points f_vector, generates the best columns to select such that changeover cost is least from first (dummy port) to last port.\n

Parameters:\n
final_columns_name: index of corner points.\n
compact_column_list: list of columns returned from shortest_path function. \n
"""
function shortest_path(f_vector, d1; printInfo = false)
    #Stores only non-zero values of f_vector.
    cp_vector = OrderedDict()
    #Populate the cp_vector
    for k in d1.K
        if length(f_vector[k][1]) > 0
            cp_vector[k] = OrderedDict()
        end
        for cp in 1:length(f_vector[k])
            temp_dict = OrderedDict()
            for (key,value) in f_vector[k][cp]
                if value > 0
                    # println("Key: $key, Value: $value")
                    temp_dict[key] = 1
                end
            end
            if length(temp_dict) > 0
                cp_vector[k][cp] = copy(temp_dict)
            end
        end
    end
    #mapping graph node number to corner points. node_list[leg][corner_point] = node_number
    node_list = OrderedDict()
    dict_index = 1

    #Create list of nodes to use as input while generting di-graph.
    for (key_1,subdict_1) in cp_vector
        node_list[key_1] = OrderedDict()
        for key_2 in keys(subdict_1)
            dict_index += 1
            node_list[key_1][key_2] = dict_index
        end
    end
    #Add dummy origin = 1 and destination nodes = last node
    first_leg = collect(keys(node_list))[1]
    last_leg = last(collect(keys(node_list)))
    node_list[first_leg][:o] = 1
    dict_index += 1
    node_list[last_leg][:d] = dict_index
    #total number of nodes in the graph
    total_nodes = dict_index
    #Make an array of keys
    keys_array = collect(keys(node_list))
    #Graph object
    cp_graph = SimpleWeightedDiGraph(total_nodes)
    #Add edges from dummy source to leg 1 columns with weight 0
    for key_1 in keys(node_list[first_leg])
        if key_1 != :o && key_1 != :d
            weight_temp = length(cp_vector[first_leg][key_1])
            if printInfo == true println("Edge added (1, $(node_list[first_leg][key_1])) = $weight_temp") end
            # if weight_temp == 0 println("Edge added (1, $(node_list[first_leg][key_1])) = $weight_temp") end
            add_edge!(cp_graph,1,node_list[first_leg][key_1],copy(weight_temp))
        end
    end
    #Add edges to dummy destination from columns in last sailing leg.
    for key_1 in keys(node_list[last_leg])
        if key_1 != :d && key_1 != :o
            weight_temp = 0.001
            if printInfo == true println("Edge added ($(node_list[last_leg][key_1]),$total_nodes) = $weight_temp") end
            add_edge!(cp_graph,node_list[last_leg][key_1],total_nodes,copy(weight_temp))
        end
    end

    #Add nodes to rest of the di-graph only if cargoes on board the ship for more than 1 sailing leg.
    if last_leg - first_leg > 0
        #Iterate over keys of the node_list as there might be no cargoes in inbetween legs.
        for k_index in 1:(length(node_list)-1)
            for cp1 in keys(node_list[keys_array[k_index]])
                for cp2 in keys(node_list[keys_array[k_index+1]])
                    if cp1 != :o && cp2 != :d
                        weight_temp = max(generateEdgeValue(cp_vector[keys_array[k_index]][cp1],cp_vector[keys_array[k_index+1]][cp2]),0.001)
                        if printInfo == true println("Edge added ($(node_list[keys_array[k_index]][cp1]),$(node_list[keys_array[k_index+1]][cp2])) = $weight_temp") end
                        # if k_index == 3 println("Added: ",cp1, " ", cp2," Edge added ($(node_list[keys_array[k_index]][cp1]),$(node_list[keys_array[k_index+1]][cp2])) = $weight_temp") end
                        add_edge!(cp_graph,node_list[keys_array[k_index]][cp1],node_list[keys_array[k_index+1]][cp2], copy(weight_temp))
                    end
                end
            end
        end
    end
    #Generate shortest path from origin (1) to destination (last_node) in terms of node numbers.
    temp_path = enumerate_paths(dijkstra_shortest_paths(cp_graph, 1), total_nodes)
    #Generates actual (leg, cornerpoint_no) from temp_path
    actual_path = []

    #Eliminate the dummy source node and destination node to generate actual column numbers.
    k_index = 1
    node_iter = 2
    while k_index <= length(keys_array)
        leg_iter = keys_array[k_index]
        for cp_iter in keys(cp_vector[leg_iter])
            if node_list[leg_iter][cp_iter] == temp_path[node_iter]
                push!(actual_path, (leg_iter,cp_iter))
            end
        end
        k_index += 1
        node_iter += 1
    end
    return actual_path, cp_vector
end

"""
cg_master_to_mip_sol: Takes the corner point vector and weight vectors to generate final mip solution.\n

Parameters:\n
f_vector: Vector of corner points.
w_vector: Weight allocations for each corner point.
d1: Data object generated by get_data function.
"""
#
function cg_master_to_mip_sol(f_vector,w_vector,d1)
    Dict2idx=OrderedDict{Tuple{Int64,Int64},Float64};
    c_values = [Dict2idx() for k=d1.K]
    w_values = [Dict2idx() for k=d1.K]
    final_columns_name, compact_column_list = shortest_path(f_vector,d1)
    b_values = generate_b_val(final_columns_name, compact_column_list)
    #Populate c_values and w_values.
    for iter in final_columns_name
        leg_no = iter[1]
        cp_no = iter[2] #cornerpoint no
        for key in keys(compact_column_list[leg_no][cp_no])
            cargo_no = key[1]
            comp_no = key[2]
            c_values[leg_no][cargo_no,comp_no] = compact_column_list[leg_no][cp_no][cargo_no,comp_no]
            if key in keys(w_vector[leg_no][cp_no]) && w_vector[leg_no][cp_no][cargo_no,comp_no] > 0
                w_values[leg_no][cargo_no,comp_no] = w_vector[leg_no][cp_no][cargo_no,comp_no]
            end
        end
    end
    #Final integer solution
    final_sol = Dict(  #AE: this is not really right: final corner point is neither the LP nor the IP solution
        "c" => c_values,
        "w" => w_values,
        "b" => b_values,
        "obj" => d1.C_C*length(b_values))
    return final_sol
end

"""
solveSubProblemsSequential: Solves all the sub-problems sequentially.
"""
function solveSubProblemsSequential(d1::Data,master::JuMP.Model,subproblem_models::Vector{JuMP.Model},lambda::Vector{Vector{VariableRef}},changeover_constr1::JuMP.Containers.SparseAxisArray,changeover_constr2::JuMP.Containers.SparseAxisArray, convexity_constr::JuMP.Containers.DenseAxisArray, applyRepairHeur::Bool,μ::OrderedDict, mu_3::Vector{Float64}, SPvals::Vector{Float64},w_var_vector::Vector{JuMP.Containers.DenseAxisArray{VariableRef, 2, Tuple{Vector{Int64}, UnitRange{Int64}}, Tuple{JuMP.Containers._AxisLookup{Dict{Int64, Int64}}, JuMP.Containers._AxisLookup{Tuple{Int64, Int64}}}}},c_var_vector::Vector{JuMP.Containers.DenseAxisArray{VariableRef, 2, Tuple{Vector{Int64}, UnitRange{Int64}}, Tuple{JuMP.Containers._AxisLookup{Dict{Int64, Int64}}, JuMP.Containers._AxisLookup{Tuple{Int64, Int64}}}}},corner_point_no::Vector{Int64},temp_corner_points::Vector{Dict{Any, Any}},final_corner_point::Vector{OrderedDict{Tuple{Int64, Int64}, Float64}}, w_vector::Vector{Vector{Any}}, f_vector::Vector{Vector{Any}}, final_w_values::Vector{OrderedDict{Tuple{Int64, Int64}, Float64}}, initialSubProblemTimeLimit, greedy_heur_weightage)
    #Solve k sub-problems sequentially
    # Pricing loop: k Subproblems solved sequentially.
    for k in d1.K # measure the whole loop
        if length(d1.zeta_per_leg[k]) > 0
            #Populate objective function cost function
            if applyRepairHeur == true
                if k == first(d1.K) || length(temp_corner_points[k-1]) == 0
                    @timed @objective(subproblem_models[k], Min, sum(get_dw_sp_obj(d1,μ,k,j,h,0) * c_var_vector[k][j,h] for j=d1.zeta_per_leg[k] for h=d1.H))
                else
                    temp_partial_cost_coeff = Dict()
                    for j in d1.zeta_per_leg[k]
                        for h in d1.H
                            if j in d1.zeta_per_leg[k-1]
                                temp_partial_cost_coeff[(j,h)] = greedy_heur_weightage*temp_corner_points[k-1][j,h]
                            else
                                temp_partial_cost_coeff[(j,h)] = 0
                            end
                        end
                    end
                    @objective(subproblem_models[k], Min,
                            sum(get_dw_sp_obj(d1,μ,k,j,h,temp_partial_cost_coeff[(j,h)]) * c_var_vector[k][j,h]
                            for j=d1.zeta_per_leg[k] for h=d1.H))
                    # subsolvemem += substat.bytes
                end
            else
                # substat = @timed optimize!(subproblem_models[k])
                # SPvals[k] = objective_value(subproblem_models[k])
                # subsolvesec += substat.time
                @objective(subproblem_models[k], Min, sum(get_dw_sp_obj(d1,μ,k,j,h) * c_var_vector[k][j,h] for j=d1.zeta_per_leg[k] for h=d1.H))
                # subsolvemem += substat.bytes
            end
            #Start with a minimum time limit to the model and keep increasing either till optimality or till first column with favourable reduced cost is found out.
            colNotFound = true
            subProblemTimeLimit = initialSubProblemTimeLimit
            while colNotFound
                # println("Repeating while loop with time limit: $subProblemTimeLimit")
                set_time_limit_sec(subproblem_models[k],subProblemTimeLimit)
                # subsolvemem += substat.bytes
                optimize!(subproblem_models[k])
                SPvals[k] = objective_value(subproblem_models[k])
                # subsolvesec += substat.time
                #Check the column addition to master problem criteria. Reduced cost less than zero.
                # println("SPvals[k]=$(SPvals[k]), mu_3[k]=$(mu_3[k])")
                if SPvals[k] < mu_3[k] || applyRepairHeur == true
                    #Populate the columns/corner points vector.
                    corner_point_no[k] +=1
                    empty!(final_corner_point[k])
                    empty!(final_w_values[k])
                    for j=d1.zeta_per_leg[k], h=d1.H
                        final_corner_point[k][j,h] =  value(c_var_vector[k][j,h])
                        final_w_values[k][j,h] = round(value(w_var_vector[k][j,h]),digits = 3)
                    end
                    temp_corner_points[k] = final_corner_point[k]
                    push!(f_vector[k], copy(final_corner_point[k]))
                    push!(w_vector[k],copy(final_w_values[k]))
                    #Introduce new variables for the new corner points
                    newλ = @variable(master, lower_bound = 0, base_name="lambda[$k,$(length(f_vector[k]))]")
                    push!(lambda[k], newλ)
                    #Add new columns to constraints of the master problem.
                    rc = -mu_3[k]
                    for ((j,h),val) in final_corner_point[k]
                        if val < 1e-6; continue; end
                        if k != d1.K_j[j][1]
                            set_normalized_coefficient(changeover_constr2[k,j,h], newλ, -val)
                        else
                            set_normalized_coefficient(changeover_constr1[j,h], newλ, -val)
                        end
                        rc += μ[k,j,h] * val
                        if k != d1.K_j[j][end] # variable λ occurs in constraints k & k+1
                            set_normalized_coefficient(changeover_constr2[k+1,j,h], newλ, val)
                            rc -= μ[k+1,j,h] * val
                        end
                    end
                    set_normalized_coefficient(convexity_constr[k],newλ,1.0)
                    #Only check if repair heuristic are not being applied
                    if applyRepairHeur == false
                        if abs(SPvals[k]-mu_3[k]-rc) > 0.01 ##AE: Just to make sure it's all working as expected.
                            println("$iter: SP$k($(SPvals[k])) -μ3($(mu_3[k])) = ",SPvals[k]-mu_3[k]," =?= ",rc,
                                "\tk=$k K_j=",[ d1.K_j[j][1]:d1.K_j[j][end] for j=d1.zeta_per_leg[k]])
                        end
                    end
                    colNotFound = false
                    break
                elseif termination_status(subproblem_models[k]) == MOI.OPTIMAL
                    break
                else
                    # subProblemTimeLimit += 1
                    break
                end
            end
        end
    end
end

"""
solveSubProblemsParallel: Solves all the sub-problems in parallel.
"""
function solveSubProblemsParallel(d1::Data,master::JuMP.Model,subproblem_models::Vector{JuMP.Model},lambda::Vector{Vector{VariableRef}},changeover_constr1::JuMP.Containers.SparseAxisArray,changeover_constr2::JuMP.Containers.SparseAxisArray, convexity_constr::JuMP.Containers.DenseAxisArray, applyRepairHeur::Bool,μ::OrderedDict, mu_3::Vector{Float64}, SPvals::Vector{Float64},w_var_vector::Vector{JuMP.Containers.DenseAxisArray{VariableRef, 2, Tuple{Vector{Int64}, UnitRange{Int64}}, Tuple{JuMP.Containers._AxisLookup{Dict{Int64, Int64}}, JuMP.Containers._AxisLookup{Tuple{Int64, Int64}}}}},c_var_vector::Vector{JuMP.Containers.DenseAxisArray{VariableRef, 2, Tuple{Vector{Int64}, UnitRange{Int64}}, Tuple{JuMP.Containers._AxisLookup{Dict{Int64, Int64}}, JuMP.Containers._AxisLookup{Tuple{Int64, Int64}}}}},corner_point_no::Vector{Int64},temp_corner_points::Vector{Dict{Any, Any}},final_corner_point::Vector{OrderedDict{Tuple{Int64, Int64}, Float64}}, w_vector::Vector{Vector{Any}}, f_vector::Vector{Vector{Any}}, final_w_values::Vector{OrderedDict{Tuple{Int64, Int64}, Float64}}, initialSubProblemTimeLimit, mainloop_iter)
    #Vectorised to avoid same location error during parallel runs
    mainloop_iter = repeat([mainloop_iter],length(d1.K))
    #Solve k sub-problems sequentially
    # Pricing loop: k Subproblems solved sequentially.
    for k in d1.K # measure the whole loop
        if length(d1.zeta_per_leg[k]) > 0
            #Populate objective function cost function
            # substat = @timed optimize!(subproblem_models[k])
            # SPvals[k] = objective_value(subproblem_models[k])
            # subsolvesec += substat.time
            @objective(subproblem_models[k], Min,
                    sum(get_dw_sp_obj(d1,μ,k,j,h) * c_var_vector[k][j,h]
                    for j=d1.zeta_per_leg[k] for h=d1.H))
            # subsolvemem += substat.bytes
            #Start with a minimum time limit to the model and keep increasing either till optimality or till first column with favourable reduced cost is found out.
            subProblemTimeLimit = initialSubProblemTimeLimit
            # println("Repeating while loop with time limit: $subProblemTimeLimit")
            set_time_limit_sec(subproblem_models[k],subProblemTimeLimit)
            set_optimizer_attribute(subproblem_models[k],"BestBdStop",Inf)
            # set_optimizer_attribute(subproblem_models[k],"BestObjStop",-Inf)
            if applyRepairHeur == false
                set_optimizer_attribute(subproblem_models[k],"BestBdStop", mu_3[k])
                # set_optimizer_attribute(subproblem_models[k],"BestObjStop", mu_3[k])
            end
        end
    end
    #Uncomment following section to enable parallel solving
    # Threads.@threads for k in d1.K
    #     if length(d1.zeta_per_leg[k]) > 0
    #         print("Iter $(mainloop_iter[k]), sp$k: Thread: $(Threads.threadid())\n")
    #         optimize!(subproblem_models[k])
    #     end
    # end
    #Uncomment the following section to remove parallel solving
    for k in d1.K
        if length(d1.zeta_per_leg[k]) > 0
            # print("Iter $(mainloop_iter[k]), sp$k: Thread: $(Threads.threadid())\n")
            optimize!(subproblem_models[k])
        end
    end
    for k in d1.K
        if length(d1.zeta_per_leg[k]) > 0
            SPvals[k] = objective_value(subproblem_models[k])
            #Check the column addition to master problem criteria. Reduced cost less than zero.
            # println("SPvals[k]=$(SPvals[k]), mu_3[k]=$(mu_3[k])")
            if SPvals[k] < mu_3[k]
                #Populate the columns/corner points vector.
                corner_point_no[k] +=1
                empty!(final_corner_point[k])
                empty!(final_w_values[k])
                for j=d1.zeta_per_leg[k], h=d1.H
                    final_corner_point[k][j,h] =  value(c_var_vector[k][j,h])
                    final_w_values[k][j,h] = round(value(w_var_vector[k][j,h]),digits = 3)
                end
                temp_corner_points[k] = final_corner_point[k]
                push!(f_vector[k], copy(final_corner_point[k]))
                push!(w_vector[k],copy(final_w_values[k]))
                #Introduce new variables for the new corner points
                newλ = @variable(master, lower_bound = 0, base_name="lambda[$k,$(length(f_vector[k]))]")
                push!(lambda[k], newλ)
                #Add new columns to constraints of the master problem.
                rc = -mu_3[k]
                for ((j,h),val) in final_corner_point[k]
                    if val < 1e-6; continue; end
                    if k != d1.K_j[j][1]
                        set_normalized_coefficient(changeover_constr2[k,j,h], newλ, -val)
                    else
                        set_normalized_coefficient(changeover_constr1[j,h], newλ, -val)
                    end
                    rc += μ[k,j,h] * val
                    if k != d1.K_j[j][end] # variable λ occurs in constraints k & k+1
                        set_normalized_coefficient(changeover_constr2[k+1,j,h], newλ, val)
                        rc -= μ[k+1,j,h] * val
                    end
                end
                set_normalized_coefficient(convexity_constr[k],newλ,1.0)
                #Only check if repair heuristic are not being applied
                if abs(SPvals[k]-mu_3[k]-rc) > 0.01 ##AE: Just to make sure it's all working as expected.
                    println("$iter: SP$k($(SPvals[k])) -μ3($(mu_3[k])) = ",SPvals[k]-mu_3[k]," =?= ",rc,
                        "\tk=$k K_j=",[ d1.K_j[j][1]:d1.K_j[j][end] for j=d1.zeta_per_leg[k]])
                end
            end
        end
    end
end

"""
columngen: Primary function to be called to solve the column generation framework. If writeSolFile == false, it returns the best master objective, best lagrangian objective and the best integer solution. If true, it generates a solution file.\n

Parameters:\n
instance_iter: Instance set number\n
ship_no: Ship number\n
d1: Data object generated by get_data function.\n
solver=SOLVER\n
writeSolFile(Bool): Toggle for either returning the solution or writing it to a text file.\n
maxIter: Total iterations of CG before termination.\n
milp_sol_freq: Number of iterations after which shortest path heuristic is called to generate a integer solution from present set of master problem columns.\n
initialSubProblemTimeLimit: Wall clock time limit for each subproblem. \n
repairHeurIter: Number of iterations until which repair heuristic is applied.\n
repairHeurInterval: Iteration itervals at which the repair heuristic is used to modify the subproblem objective function.\n
greedy_heur_weightage: Weightage of the greedy heuristic within the sub-problem objective function. \n
wallTimeLimit: Total wall clock time limit.
"""
function columngen(instance_iter,ship_no,d1::Data;solver=SOLVER,writeSolFile=false, maxIter=200, milp_sol_freq = 50, initialSubProblemTimeLimit = 100, repairHeurIter=20, repairHeurInterval = 1, greedy_heur_weightage = 1, wallTimeLimit=450)
    println("writeSolFile=$(writeSolFile),\n maxIter=$maxIter,\n milp_sol_freq=$milp_sol_freq,\n initialSubProblemTimeLimit=$initialSubProblemTimeLimit,\n repairHeurIter=$repairHeurIter,\n repairHeurInterval=$repairHeurInterval,\n greedy_heur_weightage=$greedy_heur_weightage.")
    Dict2idx=OrderedDict{Tuple{Int64,Int64},Float64}; Dict3idx=OrderedDict{Tuple{Int64,Int64,Int64},Float64}
    b_values = Dict3idx()
    #d1 = Data();    set_data(d1,instance_iter,ship_no)
    initial_time = @timed begin
        LPbound,μLP,μLP3 = LPBound(d1,silent=true,solver=solver)
        initialSol_c, initialSol_w = initialLPSol(d1,solver=solver)
    end
    total_wall_time = initial_time.time
    # initialSol_c, initialSol_w = generateInitialMilpCols(instance_iter,ship_no,d1)
    corner_point_no = ones(Int64,length(d1.K))
    f_vector = [[] for k in d1.K] #Vector of corner points. At every iteration k corner points are added if the cargo-compartment assignment of every leg is considered as one corner point.
    w_vector = [[] for k in d1.K]
    for k in d1.K
        temp = OrderedDict()
        temp_w = OrderedDict()
        for j in d1.zeta_per_leg[k]
            for h in d1.H
                if (k,j,h) in keys(initialSol_c)
                    temp[j,h] = initialSol_c[k,j,h]
                else
                    temp[j,h] = 0
                end
                if (k,j,h) in keys(initialSol_w)
                    temp_w[j,h] = initialSol_w[k,j,h]
                else
                    temp_w[j,h] = 0
                end
            end
        end
        push!(f_vector[k],copy(temp))
        push!(w_vector[k], copy(temp_w))
    end

    #Model definition
    master = Model(solver); set_silent(master)
    #Variable definition
    @variable(master, 0 <= b[k in d1.K,j in d1.zeta_per_leg[k],h in d1.H])

    lambda = [[@variable(master, lower_bound = 0, base_name="lambda[$k,$v]")
            for v = 1:length(f_vector[k])] for k in d1.K]
    ##Defining objective function
    @objective(master, Min, d1.C_C*sum(b[k,j,h] for k in d1.K, j in d1.zeta_per_leg[k], h in d1.H))

    #Changeover constraint 2 master
    @constraint(master, changeover_constr2[k in d1.K, j in d1.zeta_per_leg[k], h in d1.H;
            k != d1.K_j[j][1]],
        sum( λ * f[j,h] for (λ,f) in zip(lambda[k-1],f_vector[k-1]) ) -
        sum( λ * f[j,h] for (λ,f) in zip(lambda[k],f_vector[k]))  >=  - b[k,j,h]) # r[k,j,h]
    #Changeover constraint 1 master
    @constraint(master, changeover_constr1[j in d1.zeta, h in d1.H; length(d1.K_j[j])>0],
              # possibly empty list
        -sum( λ * f[j,h] for k=[d1.K_j[j][1]] for (λ,f) = zip(lambda[k],f_vector[k]))
        >= -b[d1.K_j[j][1],j,h])
    #Convexity constraint
    @constraint(master, convexity_constr[k in d1.K], sum(lambda[k]) == 1)
    # total_constrs_master = num_constraints(master; count_variable_in_set_constraints = true)
    total_constrs_master = sum(num_constraints(master, F, S) for (F, S) in list_of_constraint_types(master))
    if solver_name(master) == "CPLEX"
        set_optimizer_attribute(master, "CPXPARAM_ClockType", 1)
        set_optimizer_attribute(master, "CPXPARAM_Threads", 4)
    elseif solver_name(master) == "Gurobi"
        set_optimizer_attribute(master, "Threads", 4)
    end
    masterObj, lagrangianObj = [], [];
    ϵ = 1e-7
    #Create sub-problem models. Update objective function based on dual values during every iteration
    subprobs = [subproblem(d1,k,solver=solver) for k=d1.K] # note: empty model if d1.zeta_per_leg[k]==[]
    subproblem_models = [ S[1] for S=subprobs]
    c_var_vector =      [ S[2] for S=subprobs]
    w_var_vector =      [ S[3] for S=subprobs]
    total_vars_subproblem = sum([ S[4] for S=subprobs])
    total_constrs_subproblem = sum([ S[5] for S=subprobs])
    println("total_constrs_master = $total_constrs_master")
    println("Total sub-problems = $(length(d1.K))")
    println("total_vars_subproblem = $total_vars_subproblem")
    println("total_constrs_subproblem = $total_constrs_subproblem")
    final_corner_point = [Dict2idx() for k=d1.K]# OrderedDict{Tuple{Int64,Int64},Float64}()
    final_w_values = [Dict2idx() for k=d1.K] #OrderedDict{Tuple{Int64,Int64},Float64}()
    #Containers to store best repair Heuristic solution
    repairHeur_c_cols = [Dict() for k_dash=d1.K]
    repairHeur_w_cols = [Dict() for k_dash=d1.K]
    repairHeur_best_sol = Inf
    repairHeur_wall_time = total_wall_time
    #Container to store best integer solutions
    best_int_obj = Inf
    # pre-allocate memory for all major data structures used here
    μ = OrderedDict( (k,j,h) => 0.0 for k=d1.K for j=d1.zeta_per_leg[k] for h in d1.H)
    SPvals = [0.0 for k in d1.K];
    mu_3 = [0.0 for k=d1.K]
    for iter=1:maxIter
        pstat = @timed begin
            total_vars_master = num_variables(master)
            println("total_vars_master = $total_vars_master")
            optimize!(master)
            for k=d1.K, j=d1.zeta_per_leg[k], h=d1.H; b_values[k,j,h] = value(b[k,j,h]); end
            push!(masterObj, objective_value(master))

            ##AE: Change sign of duals. For problem min cᵀ x s.t A x = b, x ≥ 0
            ##    reduced cost = cⱼ - μᵀ Aⱼ where μ=dual, cⱼ = cost = 0, Aⱼ = column j of matrix
            for k=d1.K, j=d1.zeta_per_leg[k], h=d1.H;
                if k==d1.K_j[j][1]; μ[k,j,h] = abs(dual(changeover_constr1[j,h]))
                else;               μ[k,j,h] = abs(dual(changeover_constr2[k,j,h])); end
            end
            for k=d1.K; mu_3[k] = dual(convexity_constr[k]); end #Dual variables
            for (k,j,h) in keys(μ);  # check everything is correct checking
                if μ[k,j,h] > d1.C_C + 1e-5
                    println("Excessive dual: μ[$k,$j,$h]=$(μ[k,j,h]) > $(d1.C_C)")
                end
            end
            ## convex combination to stabilize initial duals
            nWarmUp = 100
            if iter < nWarmUp
                α = iter/nWarmUp
                for (k,j,h) in keys(μ); μ[k,j,h] = α*μ[k,j,h]+(1-α)*μLP[k,j,h]; end
                mu_3 = α .* mu_3 .+ (1-α) .* μLP3
            end

            SPvals .= 0.0;  numCols = sum(length(lambda[k]) for k=d1.K)
            #A dictionary to store corner points during each iteration. Used to generate repair heuristic co-efficients and calculate heuriristic objetive value.
            temp_corner_points = [Dict() for k_dash=d1.K]
            sp_heur_obj_value = Inf #Sub problem heuristic value generated only for iterations that execute heuristic for sub-problem.

            #Repair heuristic activates for following conditions
            applyRepairHeur = false
            if (iter == 1 && repairHeurIter > 0) || (iter <= repairHeurIter && iter%repairHeurInterval == 0)
                applyRepairHeur = true
            end
                if applyRepairHeur == true
                    solveSubProblemsSequential(d1,master,subproblem_models,lambda,changeover_constr1,changeover_constr2, convexity_constr, applyRepairHeur,μ, mu_3, SPvals,w_var_vector,c_var_vector,corner_point_no,temp_corner_points,final_corner_point, w_vector, f_vector, final_w_values, initialSubProblemTimeLimit, greedy_heur_weightage)
                else
                    solveSubProblemsParallel(d1,master,subproblem_models,lambda,changeover_constr1,changeover_constr2, convexity_constr, applyRepairHeur,μ, mu_3, SPvals,w_var_vector,c_var_vector,corner_point_no,temp_corner_points,final_corner_point, w_vector, f_vector, final_w_values, initialSubProblemTimeLimit, iter)
                end
        end
        #Calculate heuristic objective till repairHeurIter. If repairHeurIter >0 then always apply heuristic at first iteration and then at every repairHeurInterval iteration.
        if applyRepairHeur == true
            sp_heur_obj_value = 0
            for k in d1.K
                if k == 1
                    for keys in keys(final_w_values[k])
                        if final_w_values[k][keys] > 0
                            sp_heur_obj_value += d1.C_C
                        end
                    end
                else
                    # sp_heur_obj_value += d1.C_C*generateEdgeValue_2(temp_corner_points[k-1],temp_corner_points[k])
                    sp_heur_obj_value += d1.C_C*generateEdgeValueOnWeight_2(final_w_values[k-1],final_w_values[k])
                end
            end
        end
        # CPUtic()
        #Only do these checks when repair heuristic is not being applied. Donot change order of conditions in this if loop.
        if applyRepairHeur == false
            ##AE: Need to include the "b" subproblems where b > 0 if its reduced cost is < 0
            ##    Just checking - I think this won't actually happen in practice (?)
            if false; # do checks
                bRedCost = [d1.C_C + (k == d1.K_j[j][1] ? -μ[k,j,h] : μ[k,j,h]) for k in d1.K for j in d1.zeta_per_leg[k] for h in d1.H ]
                bRC = [ rc for rc=bRedCost if rc < -ϵ]
                if ! isempty(bRC); println("rc = ",bRC, "LB=",lagrangianObj[end]," < ",masterObj[end]);end
                push!(lagrangianObj, lagrangian(SPvals,μ,mu_3) + sum( min(0,rc) for rc=bRedCost))
            else # normal operation
                push!(lagrangianObj, lagrangian(SPvals,μ,mu_3) )
            end
            numCols = sum(length(lambda[k]) for k=d1.K) - numCols
            @printf("%3d: Master=%7.2f LagLB=%7.2f +cols=%d  time=%.2fsec BestLagLB=%7.2f\n", iter,last(masterObj),last(lagrangianObj),numCols, pstat.time, findmax(lagrangianObj)[1])
            flush(stdout)
            if lagrangianObj[end] > masterObj[end]*(1-ϵ);  # AE: additional convergence check
                if lagrangianObj[end] > masterObj[end]*(1+ϵ); # Bug?
                    println("LB=",lagrangianObj[end]," >! ",masterObj[end],"Σ SP=",SPvals," const=",sum(mu_3))
                end
                break;
            end
            if minimum(SPvals[k]-mu_3[k] for k in d1.K) >= 0; break; end #no new column
        end
        iter_time = pstat.time
        repairHeur_wall_time += copy(iter_time)
        if applyRepairHeur == true
            push!(lagrangianObj, -Inf);
            numCols = sum(length(lambda[k]) for k=d1.K) - numCols
            @printf("%3d: Master= %7.2f LagLB= %7.2f +cols= %d  time= %.2f sec, Sp_heur_obj= %7.2f, Total Wall time= %7.2f, BestLagLB=%7.2f\n",
                iter,last(masterObj),last(lagrangianObj),numCols,
                pstat.time, sp_heur_obj_value, repairHeur_wall_time,findmax(lagrangianObj)[1])
            flush(stdout)
        end
        #Generte milp solution every 'milp_sol_freq' iterations
        if iter%milp_sol_freq == 0
            #To make sure atleast one cornerpoint is generated
            if sum(corner_point_no) > length(d1.K)
                milp_stat = @timed final_sol = cg_master_to_mip_sol(f_vector, w_vector,d1)
                if writeSolFile && final_sol["obj"] < best_int_obj
                    best_int_obj = final_sol["obj"]
                    writeSoltoFile(d1,instance_iter, ship_no, last(masterObj), findmax(lagrangianObj)[1], final_sol, -1, wall_time = repairHeur_wall_time)
                    println("*Milp sol: Iter: $iter, Master Obj: $(round(last(masterObj), digits = 2)), Lagrangian Obj: $(round(findmax(lagrangianObj)[1], digits =2)), Integer Obj: $(final_sol["obj"]), Total Wall time: $(repairHeur_wall_time), repairHeur Best Obj:$(repairHeur_best_sol), milp_time: $(milp_stat.time)")
                end
                # empty!(final_sol)
            else
                println("No integer columns found for instance: $instance_iter, ship: $ship_no")
                final_sol = Dict(
                    "c" => Dict(),
                    "w" => Dict(),
                    "b" => Dict(),
                    "obj" => "NotFound")
                if writeSolFile
                    writeSoltoFile(d1,instance_iter, ship_no, last(masterObj), findmax(lagrangianObj)[1], final_sol)
                else
                    println("*Milp sol: Iter: $iter, Master Obj: $(last(masterObj)), Lagrangian Obj: $(findmax(lagrangianObj)[1]), Integer Obj: $(final_sol["obj"]), repairHeur Best Obj: $(repairHeur_best_sol)")
                end
            end
        end
        #Store and write the best repair Heuristic solution
        if sp_heur_obj_value < repairHeur_best_sol
            #Update best sol
            repairHeur_best_sol = sp_heur_obj_value
            #Update c_values and w_values
            for k in d1.K
                empty!(repairHeur_c_cols[k])
                empty!(repairHeur_w_cols[k])
                repairHeur_c_cols[k] = temp_corner_points[k]
                repairHeur_w_cols[k] = final_w_values[k]
            end
            #Write repairHeur solution to file
            # repairHeur_cpu_time = CPUtoc() + repairHeur_cpu_time
            writeRepairHeurSolToFile(instance_iter, ship_no, iter, d1.K, repairHeur_c_cols, repairHeur_w_cols, repairHeur_best_sol, repairHeur_wall_time)
        end
        if repairHeur_wall_time >= wallTimeLimit
            break
        end
    end
    # cpu_time_elapsed = CPUtoc() + repairHeur_cpu_time
    # cpu_time_elapsed = repairHeur_cpu_time
    total_wall_time = repairHeur_wall_time
    for final in [final_corner_point, final_w_values]
        for k=d1.K, (key,val)=final[k] # remove zero valued entries
             if abs(val) < 1e-6; delete!(final[k],key); end
        end
    end
    println("Main loop took $(total_wall_time)sec")
    # Check whether atleast 1 integer column is generated
    if sum(corner_point_no) > length(d1.K)
        milp_stat = @timed final_sol = cg_master_to_mip_sol(f_vector, w_vector,d1)
        println("*Final milp sol: Master Obj: $(round(last(masterObj), digits = 2)), Lagrangian Obj: $(round(findmax(lagrangianObj)[1], digits =2)), Integer Obj: $(final_sol["obj"]), repairHeur Best Obj: $(repairHeur_best_sol), milp_time: $(milp_stat.time)")
    else
        println("No integer columns found for instance: $instance_iter, ship: $ship_no")
        final_sol = Dict(  #AE: this is not really right: final corner point is neither the LP nor the IP solution
            "c" => Dict(),
            "w" => Dict(),
            "b" => Dict(),
            "obj" => "NotFound")
    end
    if writeSolFile && final_sol["obj"] < best_int_obj
        writeSoltoFile(d1,instance_iter, ship_no, last(masterObj), findmax(lagrangianObj)[1], final_sol, -1, wall_time = total_wall_time)
        empty!(final_sol)
        # return masterObj, lagrangianObj, final_sol
    else
        # return masterObj, lagrangianObj, f_vector, w_vector
        return masterObj, lagrangianObj, final_sol
    end
    # return masterObj, lagrangianObj, final_sol
end



inst = 3
ship = 7
if !local_path
    inst = parse(Int64,ARGS[1])
    ship = parse(Int64,ARGS[2])
end
flush(stdout)
println("Presolve instance:")
columngen(22,3,get_data(22,3),maxIter=1,repairHeurIter=0) # test-run to force compilation of functions
println("="^60)
println("Primary instance:")
println("Running Instance $inst, ship $ship using $(solver_name(Model(SOLVER)))")
dat = get_data(inst,ship)
println("K=$(length(dat.K)), J=$(length(unique(reduce(vcat,dat.zeta_per_leg)))), H=$(length(dat.H))")
# @time @CPUtime  masterObj, lagObj, milp_sol = columngen(inst,ship,dat,maxIter=1000, writeSolFile=false, initialSubProblemTimeLimit = 0.5)
# @time @CPUtime  masterObj, lagObj, f_vector, w_vector = columngen(inst,ship,dat,maxIter=1000, writeSolFile=false)
columngen(inst,ship,dat,maxIter=10000, writeSolFile=true, milp_sol_freq = 20, initialSubProblemTimeLimit = 60, repairHeurIter= 200, greedy_heur_weightage = 250, repairHeurInterval = 5, wallTimeLimit = 86400)

# for (keys,value) in w_vector
#     println("$key, $value")
# end
